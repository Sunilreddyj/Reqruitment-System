import React from 'react';
import { Link } from 'react-router-dom';
import { BriefcaseIcon, BuildingIcon, UserIcon } from 'lucide-react';

const Home = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center py-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Find Your Dream Job Today
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Connect with top companies and discover exciting opportunities
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/jobs"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <BriefcaseIcon className="h-5 w-5" />
            Browse Jobs
          </Link>
          <Link
            to="/register"
            className="bg-white text-blue-600 border-2 border-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 flex items-center gap-2"
          >
            <UserIcon className="h-5 w-5" />
            Create Account
          </Link>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <BriefcaseIcon className="h-12 w-12 text-blue-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Find Jobs</h2>
          <p className="text-gray-600">
            Browse through thousands of job listings from top companies.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <BuildingIcon className="h-12 w-12 text-blue-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Company Profiles</h2>
          <p className="text-gray-600">
            Research companies and find the perfect cultural fit for you.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <UserIcon className="h-12 w-12 text-blue-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Career Growth</h2>
          <p className="text-gray-600">
            Take the next step in your professional journey.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;