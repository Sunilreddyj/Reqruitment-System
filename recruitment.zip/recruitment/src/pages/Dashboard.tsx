import React from 'react';
import { useAuth } from '../context/AuthContext';
import { BriefcaseIcon, ClipboardIcon, UserIcon } from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex items-center gap-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <UserIcon className="h-8 w-8 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{user?.name}</h1>
            <p className="text-gray-600">{user?.email}</p>
          </div>
        </div>
      </div>

      {user?.role === 'company' ? (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <BriefcaseIcon className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold">Posted Jobs</h2>
            </div>
            <p className="text-gray-600">No jobs posted yet.</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <ClipboardIcon className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold">Applications</h2>
            </div>
            <p className="text-gray-600">No applications received yet.</p>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <BriefcaseIcon className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold">My Applications</h2>
            </div>
            <p className="text-gray-600">No applications submitted yet.</p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <ClipboardIcon className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold">Saved Jobs</h2>
            </div>
            <p className="text-gray-600">No saved jobs yet.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;