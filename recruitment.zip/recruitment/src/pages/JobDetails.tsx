import React from 'react';
import { useParams } from 'react-router-dom';
import { MapPinIcon, ClockIcon, BriefcaseIcon, BuildingIcon } from 'lucide-react';

// Temporary mock data until API integration
const mockJob = {
  _id: '1',
  title: 'Senior React Developer',
  company: 'Tech Corp',
  location: 'San Francisco, CA',
  type: 'full-time',
  salary: '$120,000 - $150,000',
  description: 'We are looking for an experienced React developer to join our team...',
  requirements: [
    'Minimum 5 years of experience with React',
    'Strong understanding of state management',
    'Experience with TypeScript',
    'Excellent communication skills',
  ],
  createdAt: new Date(),
};

const JobDetails = () => {
  const { id } = useParams();

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{mockJob.title}</h1>
            <div className="flex items-center mt-2">
              <BuildingIcon className="h-5 w-5 text-gray-500 mr-2" />
              <span className="text-gray-700 font-medium">{mockJob.company}</span>
            </div>
          </div>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
            Apply Now
          </button>
        </div>

        <div className="flex gap-6 mb-8 text-gray-600">
          <span className="flex items-center">
            <MapPinIcon className="h-5 w-5 mr-2" />
            {mockJob.location}
          </span>
          <span className="flex items-center">
            <BriefcaseIcon className="h-5 w-5 mr-2" />
            {mockJob.type}
          </span>
          <span className="flex items-center">
            <ClockIcon className="h-5 w-5 mr-2" />
            Posted {new Date(mockJob.createdAt).toLocaleDateString()}
          </span>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Salary Range</h2>
          <p className="text-blue-600 font-semibold text-lg">{mockJob.salary}</p>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Job Description</h2>
          <p className="text-gray-700 whitespace-pre-line">{mockJob.description}</p>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Requirements</h2>
          <ul className="list-disc list-inside space-y-2">
            {mockJob.requirements.map((req, index) => (
              <li key={index} className="text-gray-700">{req}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;