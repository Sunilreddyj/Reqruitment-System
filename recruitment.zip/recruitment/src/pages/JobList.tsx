import React from 'react';
import { Link } from 'react-router-dom';
import { MapPinIcon, ClockIcon, BriefcaseIcon } from 'lucide-react';

// Temporary mock data until API integration
const mockJobs = [
  {
    _id: '1',
    title: 'Senior React Developer',
    company: 'Tech Corp',
    location: 'San Francisco, CA',
    type: 'full-time',
    salary: '$120,000 - $150,000',
    createdAt: new Date(),
  },
  {
    _id: '2',
    title: 'Product Manager',
    company: 'Innovation Labs',
    location: 'New York, NY',
    type: 'full-time',
    salary: '$100,000 - $130,000',
    createdAt: new Date(),
  },
];

const JobList = () => {
  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Available Jobs</h1>
        <div className="flex gap-4">
          <input
            type="text"
            placeholder="Search jobs..."
            className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <select className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Types</option>
            <option value="full-time">Full Time</option>
            <option value="part-time">Part Time</option>
            <option value="contract">Contract</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {mockJobs.map((job) => (
          <Link
            key={job._id}
            to={`/jobs/${job._id}`}
            className="block bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">{job.title}</h2>
                <p className="text-gray-600 mt-1">{job.company}</p>
                <div className="flex gap-4 mt-2">
                  <span className="flex items-center text-gray-500">
                    <MapPinIcon className="h-4 w-4 mr-1" />
                    {job.location}
                  </span>
                  <span className="flex items-center text-gray-500">
                    <BriefcaseIcon className="h-4 w-4 mr-1" />
                    {job.type}
                  </span>
                  <span className="flex items-center text-gray-500">
                    <ClockIcon className="h-4 w-4 mr-1" />
                    {new Date(job.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-blue-600 font-semibold">{job.salary}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default JobList;