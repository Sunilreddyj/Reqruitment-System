export interface User {
  _id?: string;
  name: string;
  email: string;
  password: string;
  role: 'company' | 'candidate';
}

export interface Job {
  _id?: string;
  title: string;
  company: string;
  location: string;
  description: string;
  requirements: string[];
  salary: string;
  type: 'full-time' | 'part-time' | 'contract';
  postedBy: string;
  createdAt: Date;
}

export interface Application {
  _id?: string;
  jobId: string;
  userId: string;
  status: 'pending' | 'accepted' | 'rejected';
  resume: string;
  coverLetter: string;
}

export interface Interview {
  _id?: string;
  applicationId: string;
  dateTime: Date;
  location: string;
  type: 'online' | 'in-person';
  notes?: string;
}